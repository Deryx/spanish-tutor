#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tests import doTests

# starts all test suites
doTests()
