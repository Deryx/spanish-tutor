#!/usr/bin/env python
# -*- coding: utf-8 -*-

from objectpath import shell

shell.main()

